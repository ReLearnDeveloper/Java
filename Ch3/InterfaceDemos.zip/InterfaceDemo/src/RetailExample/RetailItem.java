package RetailExample;

/**
   RetailItem interface
*/

public interface RetailItem
{
   public double getRetailPrice();
}
