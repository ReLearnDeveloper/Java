/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carproject;

import java.util.Comparator;

/**
 *
 * @author mtsguest
 */
public class CarComparatorByMake implements Comparator<Car> {
    
    public int compare(Car car1, Car car2)
    {
        return car1.getMake().compareTo(car2.getMake());
    }
    
}
