/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carproject;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author mtsguest
 */
public class CarProject {

    /**
     * @param args the command line arguments
     */
    ArrayList<Car> myCarCollection;
    
    public static void main(String[] args) {
        
        CarProject myProject = new CarProject();
        
        myProject.createCars();
        myProject.sortCars();
        // TODO code application logic here
    }
    
    public void createCars()
    {
        Car car1 = new Car("Toyota", "Corolla", 2018, 150, 18000);
        Car car2 = new Car("Dodge", "Ram", 2016, 300, 25000);
        Car car3 = new Car("Honda", "Civic", 2019, 250, 23000);
        Car car4 = new Car("Jeep", "Wrangler", 2019, 300, 25000);
        Car car5 = new Car("Ferrari", "Enzo", 2020, 500, 88000);
        Car car6 = new Car("Rolls Royce", "Phantom", 2018, 400, 100000);
        
        myCarCollection = new ArrayList<Car>();
        myCarCollection.add(car1);
        myCarCollection.add(car2);
        myCarCollection.add(car3);
        myCarCollection.add(car4);
        myCarCollection.add(car5);
        myCarCollection.add(car6);
        
    }
    
    public void sortCars()
    {
        System.out.println("Sorting by Make:");
        Collections.sort(myCarCollection, new CarComparatorByMake());
        System.out.println(myCarCollection);
        System.out.println("\n");
        
        System.out.println("Sorting by Horsepower:");
        Collections.sort(myCarCollection, new CarComparatorByHorsepower());
        System.out.println(myCarCollection);
        System.out.println("\n");
        
        System.out.println("Sorting by Price:");
        Collections.sort(myCarCollection);
        System.out.println(myCarCollection);
    }
}
