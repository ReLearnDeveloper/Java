/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carproject;

import java.util.Comparator;

/**
 *
 * @author mtsguest
 */
public class CarComparatorByHorsepower implements Comparator<Car> {
    
    public int compare(Car car1, Car car2)
    {
        if (car1.getHorsepower() > car2.getHorsepower())
            return 1;
        else if (car1.getHorsepower() < car2.getHorsepower())
            return -1;
        else
            return 0;
    }
    
}
