/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentdemo;
import java.util.Comparator;

/**
 *
 * @author mtsguest
 */
public class StudentFirstNameComparator implements Comparator<Student> {
    
    public int compare(Student stud1, Student stud2)
    {
        return stud1.getFirstName().compareTo(stud2.getFirstName());
    }
    
}
