/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enjoyableinterfaceexample;

/**
 *
 * @author mtsguest
 */
public interface Enjoyable {
    
    public int schedule(boolean doIt);
    
}
