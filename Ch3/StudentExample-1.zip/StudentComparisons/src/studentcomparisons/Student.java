/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentcomparisons;

/**
 *
 * @author mtsguest
 */
public class Student implements Comparable<Student> {
    
    private String firstName;
    private double gpa;
    private int year;

    public Student(String firstName, double gpa, int year) {
        this.firstName = firstName;
        this.gpa = gpa;
        this.year = year;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return "Student{" + "firstName=" + firstName + ", gpa=" + gpa + ", year=" + year + '}';
    }
    
    public int compareTo(Student other)
    {
        if (gpa > other.gpa)
        {
            return -1;
        }
        else if (gpa < other.gpa)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    
}
