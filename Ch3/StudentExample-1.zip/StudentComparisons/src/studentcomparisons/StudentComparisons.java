/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentcomparisons;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author mtsguest
 */
public class StudentComparisons {

    /**
     * @param args the command line arguments
     */
    static ArrayList<Student> myStudents;
    
    public static void main(String[] args) {
       createStudents();
       sortAndPrint();
    }
    
    public static void createStudents()
    {
        Scanner keyboard = new Scanner(System.in);
        myStudents = new ArrayList<Student>();
        boolean moreStudents = true;
        String firstName;
        double gpa;
        int year;
        Student aStudent;
        
        while (moreStudents)
        {
            System.out.println("What is your first name?");
            firstName = keyboard.nextLine();
            System.out.println("What is your gpa? (4.0 scale)");
            gpa = keyboard.nextDouble();
            keyboard.nextLine();
            System.out.println("What year are you in? (1=freshman 2=sophmore 3=junior 4=senior");
            year = keyboard.nextInt();
            keyboard.nextLine();
            
            aStudent = new Student(firstName, gpa, year);
            myStudents.add(aStudent);
                 
            System.out.println("Do you have more students? (true or false)");
            moreStudents = keyboard.nextBoolean();
            keyboard.nextLine();
        }
        
        System.out.println(myStudents);
        
    }
    
    public static void sortAndPrint()
    {
            Collections.sort(myStudents);
            System.out.println(myStudents);
            
    }
    
    
    
}
