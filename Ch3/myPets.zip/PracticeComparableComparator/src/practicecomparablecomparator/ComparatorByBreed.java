/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicecomparablecomparator;

import java.util.Comparator;

/**
 *
 * @author mtsguest
 */
public class ComparatorByBreed implements Comparator 
{
    public int compare(Object a, Object b)
    {
        Pet firstPet = (Pet)a;
        Pet secondPet = (Pet) b;
        
        if (firstPet.getBreed().compareTo(secondPet.getBreed()) == 0)
            return 0;
        else if (firstPet.getBreed().compareTo(secondPet.getBreed()) > 1)
            return 1;
        else
            return -1;
        
        
        
    }
}
