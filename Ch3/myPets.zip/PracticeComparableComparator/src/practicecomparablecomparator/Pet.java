/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicecomparablecomparator;
import java.util.ArrayList;

/**
 *
 * @author mtsguest
 */
public class Pet implements Comparable 
{
    private String breed;
    private String name;
    private double weight;
    private ArrayList<String> prevOwners;
    
    public Pet(String aBreed, String aName, double aWeight, ArrayList<String> aPrevOwners)
    {
        breed = aBreed;
        name = aName;
        weight = aWeight;
        prevOwners = new ArrayList<String>(aPrevOwners);
    }

    /**
     * @return the breed
     */
    public String getBreed() {
        return breed;
    }

    /**
     * @param breed the breed to set
     */
    public void setBreed(String breed) {
        this.breed = breed;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the weight
     */
    public double getWeight() {
        return weight;
    }

    /**
     * @param weight the weight to set
     */
    public void setWeight(double weight) {
        this.weight = weight;
    }
    
//    public int compareTo(Object aPet)
//    {
//        Pet otherPet = (Pet) aPet;
//        if (breed.compareTo(otherPet.breed) == 0)
//            return 0;
//        else if (breed.compareTo(otherPet.breed) > 1)
//            return 1;
//        else
//            return -1;
//    }
    
    public int compareTo(Object aPet)
    {
        Pet otherPet = (Pet) aPet;
        if (weight > otherPet.weight)
            return 1;
        else if (weight < otherPet.weight)
            return -1;
        else 
            return 0;
    }
    
    
    public String toString()
    {
        String strPrevOwners = "Previous Owners: \n";
        for (int i=0; i < prevOwners.size(); i++)
        {
            strPrevOwners += prevOwners.get(i) + "\n ";
        }
        return "Breed: " + breed + "\n" + "Name: " + name + " Weight: " + weight + strPrevOwners;
    }
    
}
