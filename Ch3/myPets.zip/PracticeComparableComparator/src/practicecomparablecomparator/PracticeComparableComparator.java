/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicecomparablecomparator;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author mtsguest
 */
public class PracticeComparableComparator {

    /**
     * @param args the command line arguments
     */
    ArrayList<Pet> myPets;
    ArrayList<String> myPrevOwners;
    
    public static void main(String[] args) 
    {
        PracticeComparableComparator practice = new PracticeComparableComparator();
        practice.createArrayList();
        practice.processArrayList();
         
        
    }
    
    public void createArrayList()
    {
        myPets = new ArrayList<Pet>();
        
        myPrevOwners = new ArrayList<String>();
        myPrevOwners.add("Cristy");
        myPrevOwners.add("Christopher");
        myPrevOwners.add("Nick");
        Pet pet1 = new Pet("Husky", "Fido", 70.5, myPrevOwners);
        
        myPrevOwners = new ArrayList<String>();
        myPrevOwners.add("Cristy");
        myPrevOwners.add("Christopher");
        myPrevOwners.add("Nick");
        Pet pet2 = new Pet("Pony", "Robert", 250.75, myPrevOwners);
        
        myPrevOwners = new ArrayList<String>();
        myPrevOwners.add("Cristy");
        myPrevOwners.add("Christopher");
        myPrevOwners.add("Nick");
        Pet pet3 = new Pet("Parakeet", "Cornelius", .15, myPrevOwners);
        
        myPrevOwners = new ArrayList<String>();
        myPrevOwners.add("Cristy");
        myPrevOwners.add("Christopher");
        myPrevOwners.add("Nick");
        Pet pet4 = new Pet("Cat", "Misty", 5.6, myPrevOwners);
        
        myPrevOwners = new ArrayList<String>();
        myPrevOwners.add("Cristy");
        myPrevOwners.add("Christopher");
        myPrevOwners.add("Nick");
        Pet pet5 = new Pet("Hamster", "Fred", 1.2, myPrevOwners);
        
        myPets.add(pet1);
        myPets.add(pet2);
        myPets.add(pet3);
        myPets.add(pet4);
        myPets.add(pet5);
    }
    
    public void processArrayList()
    {
        System.out.println("By Weight:");
        Collections.sort(myPets);
        for (int i= 0; i < myPets.size(); i++)
        {
            System.out.println(myPets.get(i));
        }
        
        System.out.println("\nBy Breed:");
        Collections.sort(myPets, new ComparatorByBreed());
        for (int i= 0; i < myPets.size(); i++)
        {
            System.out.println(myPets.get(i));
        }
        
    }
    
}
