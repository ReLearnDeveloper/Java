/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petstore;

/**
 *
 * @author PG6
 */
public class Pet implements Comparable<Pet>
{
    String breed;
    String name;
    double weight;
    
    public Pet(String aBreed, String aName, double aWeight)
    {
        breed = aBreed;
        name = aName;
        weight = aWeight;
    }
    
    public int compareTo(Pet aPet)
    {
        if (weight > aPet.weight)
            return 1;
        else if (weight < aPet.weight)
            return -1;
        else
            return 0;
    }
    
    public String toString()
    {
        return "Breed: " + breed + "\nName: " + name + "\nWeight: " + weight;
    }
}
