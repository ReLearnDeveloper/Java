/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petstore;
import java.util.Arrays;

/**
 *
 * @author PG6
 */
public class PetStore {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Pet[] myPets = new Pet[5];
        myPets[0] = new Pet("Cocker Spaniel", "Princess", 36.5);
        myPets[1] = new Pet("Eagle", "Captain", 5.8);
        myPets[2] = new Pet("Butterfly", "Lovely", .005);
        myPets[3] = new Pet("Ant", "Busy", .0001);
        myPets[4] = new Pet("Elephant", "Pinky", 2500);
        
        Arrays.sort(myPets);
        
        for (int i = 0; i < myPets.length; i++)
        {
            System.out.println(myPets[i] + "\n");
        }
        
        
    }
    
}
