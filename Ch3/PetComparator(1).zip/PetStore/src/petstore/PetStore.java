/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petstore;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
 *
 * @author mtsguest
 */
public class PetStore {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Pet myPet1 = new Pet("Pomeranian", "Lucky", 5.0);
       Pet myPet2 = new Pet("Cockatiel", "Monster", .25);
       Pet myPet3 = new Pet("Iguana", "Richard", .32);
       Pet myPet4 = new Pet("Pomeranian", "Julie", 4.5);
       Pet myPet5 = new Pet("Great Dane", "Scooby Doo", 38.9);
       
       Pet[] myPets = new Pet[5];
       myPets[0] = myPet1;
       myPets[1] = myPet2;
       myPets[2] = myPet3;
       myPets[3] = myPet4;
       myPets[4] = myPet5;
       
       Arrays.sort(myPets);
       
       for (Pet any: myPets)
       {
           System.out.println(any);
       }
       //*******************************************************
       
       Pet myPet1a = new Pet("Pomeranian", "Lucky", 5.0);
       Pet myPet2a = new Pet("Cockatiel", "Monster", .25);
       Pet myPet3a = new Pet("Iguana", "Richard", .32);
       Pet myPet4a = new Pet("Pomeranian", "Julie", 4.5);
       Pet myPet5a = new Pet("Great Dane", "Scooby Doo", 38.9);
       
       ArrayList<Pet> myPetsX = new ArrayList<Pet>();
       myPetsX.add(myPet1a);
       myPetsX.add(myPet2a);
       myPetsX.add(myPet3a);
       myPetsX.add(myPet4a);
       myPetsX.add(myPet5a);
       
       Collections.sort(myPetsX);
       System.out.println("********* About to print ArrayLIST by BREED **************");
       for (Pet any: myPetsX)
       {
           System.out.println(any);
       }
       
       Collections.sort(myPetsX, new PetComparatorByWeight());
        System.out.println("********* About to print ArrayLIST by WEIGHT **************");
       for (Pet any: myPetsX)
       {
           System.out.println(any);
       }
       
        Collections.sort(myPetsX, new PetComparatorByName());
        System.out.println("********* About to print ArrayLIST by Name **************");
       for (Pet any: myPetsX)
       {
           System.out.println(any);
       }
    }
    } 

