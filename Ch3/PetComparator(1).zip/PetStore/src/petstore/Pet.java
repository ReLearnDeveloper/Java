/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petstore;

/**
 *
 * @author mtsguest
 */
public class Pet implements Comparable<Pet> {
    private String breed;
    private String name;
    private double weight;

    public Pet(String breed, String name, double weight) {
        this.breed = breed;
        this.name = name;
        this.weight = weight;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "Pet{" + "breed=" + breed + ", name=" + name + ", weight=" + weight + '}';
    }
    
    public int compareTo(Pet otherPet)
    {
        return this.breed.compareToIgnoreCase(otherPet.breed);
//        if (this.weight > otherPet.weight)
//            return 1;
//        else if (this.weight == otherPet.weight)
//            return 0;
//        else
//            return -1;
  //      return this.name.compareToIgnoreCase(otherPet.name);
   
    }
    
}
